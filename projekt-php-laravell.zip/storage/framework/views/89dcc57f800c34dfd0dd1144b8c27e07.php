<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['type' => 'submit', 'variant' => 'primary']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['type' => 'submit', 'variant' => 'primary']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $classes = match ($variant) {
        'primary' => 'bg-blue-600 hover:bg-blue-700 text-white',
        'secondary' => 'bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50',
        'danger' => 'text-red-600 hover:text-red-700',
        'link' => 'text-blue-600 hover:text-blue-800',
        default => 'bg-blue-600 hover:bg-blue-700 text-white',
    };
?>

<button
    type="<?php echo e($type); ?>"
    <?php echo e($attributes->merge(['class' => "inline-flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-colors $classes"])); ?>

>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/components/btn.blade.php ENDPATH**/ ?>