<?php $__env->startSection('menu'); ?>
    <a href="/my-reservations/create" class="text-blue-500">Nowa rezerwacja</a>
    <a href="/my-reservations" class="text-blue-500">Moje rezerwacje</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($title); ?></h1>

    <p>Rezerwacja została utworzona.</p>

    <div class="bg-zinc-100 border border-zinc-200 rounded-lg shadow-md p-4 mb-4">
        <p><strong><?php echo e($reservation->guest_first_name); ?> <?php echo e($reservation->guest_last_name); ?></strong></p>
        <p class="text-zinc-600 text-sm"><?php echo e($reservation->guest_email); ?> | <?php echo e($reservation->guest_phone); ?></p>
        <p class="text-zinc-600 text-sm"><?php echo e($reservation->date_from); ?> — <?php echo e($reservation->date_to); ?></p>
        <p class="text-zinc-600 text-sm">Pokój ID: <?php echo e($reservation->room_id); ?></p>
        <p class="text-zinc-600 text-sm">Status: <?php echo e($reservation->status); ?></p>
    </div>

    <a href="/my-reservations" class="text-blue-500">Wróć do listy</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/clientReservations/show.blade.php ENDPATH**/ ?>