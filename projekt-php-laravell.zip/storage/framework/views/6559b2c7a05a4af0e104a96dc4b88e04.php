<div class="bg-white rounded-lg shadow-md p-4">
    <h1 class="text-2xl font-bold"><?php echo e($title); ?></h1>
    <p class="text-gray-600"><?php echo e($slot); ?></p>
</div><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/components/card.blade.php ENDPATH**/ ?>