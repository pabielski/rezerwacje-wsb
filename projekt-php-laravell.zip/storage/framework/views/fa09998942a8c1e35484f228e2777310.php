<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <a href="/hotels-public" class="text-sm text-muted hover:text-brand font-medium">← Lista hoteli</a>
        <h1 class="text-2xl font-bold text-heading mt-2"><?php echo e($title); ?></h1>
        <p class="text-sm text-muted mt-1"><?php echo e($hotel->city); ?>, <?php echo e($hotel->address); ?></p>
    </div>

    <div class="bg-surface border border-border rounded-2xl shadow-sm overflow-hidden">
        <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="p-5 border-b border-border last:border-b-0 hover:bg-page/50 transition-colors flex flex-wrap items-center justify-between gap-4">
                <div>
                    <h2 class="text-lg font-bold text-heading"><?php echo e($room->name); ?> <span class="text-muted font-normal">(nr <?php echo e($room->room_number); ?>)</span></h2>
                    <p class="text-sm text-muted mt-1">Miejsca: <?php echo e($room->capacity); ?> · <?php echo e($room->price_per_night); ?> zł / noc</p>
                    <?php if($room->description): ?>
                        <p class="text-muted text-sm mt-2"><?php echo e($room->description); ?></p>
                    <?php endif; ?>
                </div>
                <?php if(auth()->guard()->check()): ?>
                    <a href="/rooms/<?php echo e($room->id); ?>/reserve" class="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-lg text-sm font-semibold shrink-0">Rezerwuj</a>
                <?php else: ?>
                    <a href="/login" class="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-lg text-sm font-semibold shrink-0">Zaloguj się, aby zarezerwować</a>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="p-8 text-center text-muted text-sm">Brak dostępnych pokoi w tym hotelu.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/public/hotels/rooms.blade.php ENDPATH**/ ?>