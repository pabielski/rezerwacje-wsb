
<?php $__env->startSection('content'); ?>
    <h1>Edit Hotel</h1>
    <form action="hotels/update/<?php echo e($model->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" value="<?php echo e($model->name); ?>">
        <input type="text" name="description" value="<?php echo e($model->description); ?>">
        <button type="submit">Save</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/hotel/edit.blade.php ENDPATH**/ ?>