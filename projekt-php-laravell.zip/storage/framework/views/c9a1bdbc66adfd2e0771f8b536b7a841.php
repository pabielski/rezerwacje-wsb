
<?php $__env->startSection('menu'); ?>
    <a href="/hotels/create" class="text-blue-500">Create</a>
    <a href="/hotels" class="text-blue-500">List</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1><?php echo e($title); ?></h1>
    <form action="/amenities/add-to-database" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" value="<?php echo e($amenity->name); ?>">
        <input type="text" name="description" value="<?php echo e($amenity->description); ?>">
        <button type="submit">Create</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/amenity/create.blade.php ENDPATH**/ ?>