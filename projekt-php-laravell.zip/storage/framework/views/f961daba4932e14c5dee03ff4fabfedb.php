<?php $__env->startSection('menu'); ?>
    <a href="/rooms" class="px-3 py-1.5 rounded-lg text-muted hover:bg-page font-medium">← Powrót do pokoi</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="mb-6"><h1 class="text-2xl font-bold text-heading">Dodaj udogodnienie do pokoju</h1></div>
    <form method="post" class="bg-surface border border-border rounded-2xl shadow-sm p-6 max-w-xl space-y-4">
        <?php echo csrf_field(); ?>
        <div>
            <label class="block text-sm font-semibold text-heading mb-1.5">Udogodnienie</label>
            <select name="amenity_id" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20">
                <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($amenity->id); ?>"><?php echo e($amenity->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-lg text-sm font-semibold">Dodaj</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/rooms/add-amenity.blade.php ENDPATH**/ ?>