<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <a href="/hotels" class="text-sm text-muted hover:text-brand font-medium">← Lista hoteli</a>
        <h1 class="text-2xl font-bold text-heading mt-2">Edytuj hotel</h1>
    </div>

    <?php if($errors->any()): ?>
        <ul class="bg-red-50 border border-red-200 text-danger text-sm rounded-xl px-4 py-3 mb-4 list-disc list-inside">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <form action="/hotels/update/<?php echo e($model->id); ?>" method="post" class="bg-surface border border-border rounded-2xl shadow-sm p-6 max-w-xl">
        <?php echo csrf_field(); ?>
        <div class="space-y-4">
            <div>
                <label class="block text-sm font-semibold text-heading mb-1.5">Nazwa</label>
                <input type="text" name="name" value="<?php echo e(old('name', $model->name)); ?>" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20">
            </div>
            <div>
                <label class="block text-sm font-semibold text-heading mb-1.5">Miasto</label>
                <input type="text" name="city" value="<?php echo e(old('city', $model->city)); ?>" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20">
            </div>
            <div>
                <label class="block text-sm font-semibold text-heading mb-1.5">Adres</label>
                <input type="text" name="address" value="<?php echo e(old('address', $model->address)); ?>" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20">
            </div>
            <div>
                <label class="block text-sm font-semibold text-heading mb-1.5">Opis</label>
                <input type="text" name="description" value="<?php echo e(old('description', $model->description)); ?>" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20">
            </div>
            <button type="submit" class="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-lg text-sm font-semibold">Zapisz</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/hotels/edit.blade.php ENDPATH**/ ?>