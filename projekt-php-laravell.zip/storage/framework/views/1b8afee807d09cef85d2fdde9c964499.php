<?php $__env->startSection('content'); ?>
    <h1>Hotel</h1>
    <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-zinc-100 border border-zinc-200 rounded-lg shadow-md p-4 mb-4">
        <h1 class="text-xl font-bold"><?php echo e($hotel->name); ?></h1>
        <p class="text-zinc-600 text-sm"><?php echo e($hotel->description); ?></p>
        <div>
        <a href="<?php echo e(url()->current()); ?>/<?php echo e($hotel->id); ?>" class="text-green-500">View</a>
        <a href="<?php echo e(url()->current()); ?>/edit/<?php echo e($hotel->id); ?>" class="text-blue-500">Edit</a>
        <a href="<?php echo e(url()->current()); ?>/delete/<?php echo e($hotel->id); ?>" class="text-red-500">Delete</a>
    </div>
    </div>
   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/hotel/index.blade.php ENDPATH**/ ?>