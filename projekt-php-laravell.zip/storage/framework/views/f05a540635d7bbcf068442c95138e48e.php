<?php $__env->startSection('menu'); ?>
    <a href="/rooms/create" class="text-blue-500">Create</a>
    <a href="/rooms" class="text-blue-500">List</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1>Edit Hotel</h1>
    <form action="/rooms/update/<?php echo e($room->id); ?>" method="post">
        <?php echo csrf_field(); ?>
           <input type="text" name="name" value="<?php echo e($room->name); ?>">
         <input type="text" name="hotel_id" value="<?php echo e($room->hotel_id); ?>">
        <input type="text" name="description" value="<?php echo e($room->description); ?>">
        <input type="text" name="room_number" value="<?php echo e($room->room_number); ?>">
        <input type="text" name="capacity" value="<?php echo e($room->capacity); ?>">
        <input type="text" name="price" value="<?php echo e($room->price_per_night); ?>">
        <button type="submit">Save</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/rooms/edit.blade.php ENDPATH**/ ?>