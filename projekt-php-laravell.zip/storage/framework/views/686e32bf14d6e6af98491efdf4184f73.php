<?php $__env->startSection('content'); ?>
    <div class="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
            <h1 class="text-2xl font-bold text-heading"><?php echo e($title); ?></h1>
            <p class="text-sm text-muted mt-1">Wszystkie rezerwacje w systemie</p>
        </div>
        <a href="/reservations/create" class="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-lg text-sm font-semibold shrink-0">+ Dodaj rezerwację</a>
    </div>

    <form action="/reservations" method="get" class="bg-surface border border-border rounded-2xl shadow-sm p-5 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div><label class="block text-sm font-semibold text-heading mb-1.5">Gość</label><input type="text" name="search" value="<?php echo e(request('search')); ?>" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"></div>
            <div><label class="block text-sm font-semibold text-heading mb-1.5">Data od</label><input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"></div>
            <div><label class="block text-sm font-semibold text-heading mb-1.5">Data do</label><input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"></div>
            <div><label class="block text-sm font-semibold text-heading mb-1.5">Status</label><select name="status" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"><option value="">— wszystkie —</option><option value="new" <?php if(request('status') === 'new'): echo 'selected'; endif; ?>>new</option><option value="confirmed" <?php if(request('status') === 'confirmed'): echo 'selected'; endif; ?>>confirmed</option><option value="cancelled" <?php if(request('status') === 'cancelled'): echo 'selected'; endif; ?>>cancelled</option></select></div>
            <div><label class="block text-sm font-semibold text-heading mb-1.5">ID pokoju</label><input type="text" name="room_id" value="<?php echo e(request('room_id')); ?>" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"></div>
            <div><label class="block text-sm font-semibold text-heading mb-1.5">ID użytkownika</label><input type="text" name="user_id" value="<?php echo e(request('user_id')); ?>" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20"></div>
        </div>
        <button type="submit" class="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-lg text-sm font-semibold">Szukaj</button>
        <a href="/reservations" class="text-muted hover:text-heading text-sm font-medium ml-3">Wyczyść filtry</a>
    </form>

    <div class="bg-surface border border-border rounded-2xl shadow-sm overflow-hidden">
        <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="p-5 border-b border-border last:border-b-0 hover:bg-page/50 transition-colors">
                <div class="flex flex-wrap justify-between gap-2">
                    <h2 class="text-lg font-bold text-heading">#<?php echo e($reservation->id); ?> · <?php echo e($reservation->guest_first_name); ?> <?php echo e($reservation->guest_last_name); ?></h2>
                    <span class="px-2.5 py-0.5 rounded-md text-xs font-semibold bg-page text-muted"><?php echo e($reservation->status); ?></span>
                </div>
                <p class="text-muted text-sm mt-2"><?php echo e($reservation->date_from); ?> — <?php echo e($reservation->date_to); ?> · <?php echo e($reservation->total_price); ?> zł</p>
                <div class="mt-3 flex gap-4 text-sm">
                    <a href="/reservations/edit/<?php echo e($reservation->id); ?>" class="text-brand font-semibold hover:text-brand-dark">Edytuj</a>
                    <form action="/reservations/delete/<?php echo e($reservation->id); ?>" method="post" class="inline"><?php echo csrf_field(); ?><button type="submit" class="text-danger font-semibold hover:opacity-80">Usuń</button></form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="p-8 text-center text-muted">Brak rezerwacji.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/reservations/index.blade.php ENDPATH**/ ?>