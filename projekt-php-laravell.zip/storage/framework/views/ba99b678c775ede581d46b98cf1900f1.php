<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-heading"><?php echo e($title); ?></h1>
        <p class="text-sm text-muted mt-1">Wybierz hotel i zobacz dostępne pokoje</p>
    </div>

    <form action="/hotels-public" method="get" class="bg-surface border border-border rounded-2xl shadow-sm p-5 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
                <label class="block text-sm font-semibold text-heading mb-1.5">Szukaj (nazwa, adres)</label>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="np. Centrum"
                    class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20">
            </div>
            <div>
                <label class="block text-sm font-semibold text-heading mb-1.5">Miasto</label>
                <input type="text" name="city" value="<?php echo e(request('city')); ?>" placeholder="np. Kraków"
                    class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20">
            </div>
        </div>
        <button type="submit" class="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-lg text-sm font-semibold">Szukaj</button>
        <a href="/hotels-public" class="text-muted hover:text-heading text-sm font-medium ml-3">Wyczyść filtry</a>
    </form>

    <div class="bg-surface border border-border rounded-2xl shadow-sm overflow-hidden">
        <?php $__empty_1 = true; $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="p-5 border-b border-border last:border-b-0 hover:bg-page/50 transition-colors flex flex-wrap items-center justify-between gap-4">
                <div>
                    <h2 class="text-lg font-bold text-heading"><?php echo e($hotel->name); ?></h2>
                    <p class="text-muted text-sm mt-1"><?php echo e($hotel->city); ?>, <?php echo e($hotel->address); ?></p>
                    <?php if($hotel->description): ?>
                        <p class="text-muted text-sm mt-2"><?php echo e($hotel->description); ?></p>
                    <?php endif; ?>
                </div>
                <a href="/hotels-public/<?php echo e($hotel->id); ?>/rooms" class="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-lg text-sm font-semibold shrink-0">Zobacz pokoje</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="p-8 text-center text-muted text-sm">Brak dostępnych hoteli.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/public/hotels/index.blade.php ENDPATH**/ ?>