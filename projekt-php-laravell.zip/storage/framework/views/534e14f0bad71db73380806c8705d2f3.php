<?php $__env->startSection('content'); ?>
    <div class="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
            <h1 class="text-2xl font-bold text-heading"><?php echo e($title); ?></h1>
            <p class="text-sm text-muted mt-1">Wyposażenie pokoi</p>
        </div>
        <a href="/amenities/create" class="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-lg text-sm font-semibold shrink-0">+ Dodaj udogodnienie</a>
    </div>

    <form action="/amenities" method="get" class="bg-surface border border-border rounded-2xl shadow-sm p-5 mb-6">
        <div class="mb-4">
            <label class="block text-sm font-semibold text-heading mb-1.5">Szukaj (nazwa, opis)</label>
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="np. WiFi" class="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-brand focus:ring-2 focus:ring-brand/20">
        </div>
        <button type="submit" class="bg-brand hover:bg-brand-dark text-white px-5 py-2.5 rounded-lg text-sm font-semibold">Szukaj</button>
        <a href="/amenities" class="text-muted hover:text-heading text-sm font-medium ml-3">Wyczyść filtry</a>
    </form>

    <div class="bg-surface border border-border rounded-2xl shadow-sm overflow-hidden">
        <?php $__empty_1 = true; $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="p-5 border-b border-border last:border-b-0 hover:bg-page/50 transition-colors">
                <h2 class="text-lg font-bold text-heading"><?php echo e($amenity->name); ?></h2>
                <p class="text-muted text-sm mt-1"><?php echo e($amenity->description); ?></p>
                <div class="mt-3 flex gap-4 text-sm">
                    <a href="/amenities/edit/<?php echo e($amenity->id); ?>" class="text-brand font-semibold hover:text-brand-dark">Edytuj</a>
                    <form action="/amenities/delete/<?php echo e($amenity->id); ?>" method="post" class="inline"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button type="submit" class="text-danger font-semibold hover:opacity-80">Usuń</button></form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="p-8 text-center text-muted">Brak wyposażenia.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\rezerwacje-wsb\resources\views/amenity/index.blade.php ENDPATH**/ ?>