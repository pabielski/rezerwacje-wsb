<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Reservation extends Model
{
    protected $table = 'reservations';
    protected $primaryKey = 'id';

    public function room()
    {
        return $this->belongsTo(Room::class, "room_id");
    }
}
